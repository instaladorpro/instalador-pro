import { useEffect } from 'react'
import { Slot, router } from 'expo-router'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useAuthStore } from '../src/store/auth.store'
import { authService } from '../src/services/auth.service'


const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 2,
      retry: 1,
    },
  },
})

export default function RootLayout() {
  const { setSession, isLoading } = useAuthStore()

  useEffect(() => {
    let mounted = true

    authService.getSession().then(({ data }) => {
      if (!mounted) return
      setSession(data.session)
      router.replace(data.session ? '/(tabs)' : '/(auth)/login')
    })

    const { data: listener } = authService.onAuthStateChange((_event, session) => {
      if (!mounted) return
      setSession(session)
      if (!session) router.replace('/(auth)/login')
    })

    return () => {
      mounted = false
      listener.subscription.unsubscribe()
    }
  }, [])

  if (isLoading) return null

  return (
    <QueryClientProvider client={queryClient}>
      <Slot />
    </QueryClientProvider>
  )
}
